package uno;

import java.util.Scanner;

public class Inicio {

	public static void main(String[] args) {
		// TODO Esto es un comentario de una linea
		/*
		Esto es un comentario de varias lineas
		  
		
		 */
		System.out.println("Hola Mundo Monica");
		Scanner Teclado=new Scanner(System.in);
		int Numero;
		System.out.println("ingrese numero: ");
		Numero=Teclado.nextInt();
		System.out.println("El cuadrado es: ");
		System.out.println(Numero* numero * numero);

	}

}
