package uno;

public class Inicio {

	public static void main(String[] args) {
		// TODO Esto es un comentario de una linea
		/*
		Esto es un comentario de varias lineas
		  
		
		 */
		System.out.println("Hola Mundo Monica");

	}

}
